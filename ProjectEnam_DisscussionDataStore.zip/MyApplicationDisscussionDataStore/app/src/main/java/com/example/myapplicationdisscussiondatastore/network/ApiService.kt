package com.example.myapplicationdisscussiondatastore.network

    import com.example.myapplicationdisscussiondatastore.model.GetAllUserResponseItem
    import retrofit2.Call
    import retrofit2.http.GET

    interface ApiService {
        @GET("user")
        fun getAllUser() : Call<List<GetAllUserResponseItem>>
    }
