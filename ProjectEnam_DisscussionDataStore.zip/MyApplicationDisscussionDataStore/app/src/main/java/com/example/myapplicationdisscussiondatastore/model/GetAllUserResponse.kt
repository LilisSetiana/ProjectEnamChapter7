package com.example.myapplicationdisscussiondatastore.model


import com.google.gson.annotations.SerializedName

class GetAllUserResponse : ArrayList<GetAllUserResponseItem>()